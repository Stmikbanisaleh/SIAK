<div class="footer-inner">
	<div class="footer-content">
		<span class="bigger-120">
			<span class="blue bolder">2020 </span>
			&copy; All Right Recerved
		</span>						
	</div>
</div>