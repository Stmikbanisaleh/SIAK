<div class="footer-inner">
	<div class="footer-content">
		<span class="bigger-120">
			<span class="blue bolder">Payroll . 2020 </span>
			- Alpha &copy; All Right Recerved
		</span>						
	</div>
</div>