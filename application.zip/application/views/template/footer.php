<div class="footer-inner">
	<div class="footer-content">
		<span class="bigger-120">
			<span class="blue bolder"></span>
			&copy; All Right Recerved
		</span>						
	</div>
</div>